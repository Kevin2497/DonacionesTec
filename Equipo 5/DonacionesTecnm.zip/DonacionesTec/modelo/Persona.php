<?php
/*
Archivo:  Persona.php
Objetivo: clase que encapsula la información de una persona
Autor:    
*/

class Persona {

}