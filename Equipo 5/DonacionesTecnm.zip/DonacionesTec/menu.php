<link href="estilos/menu.css" rel="stylesheet" type="text/css"/>
<section class="menuSection">
<nav class="menu">
     
	<ul>
		<li> <a href="index.php" class="menu">Inicio</a> </li>
		<li> <a href="logeo.php" class="menu">Logearte</a> </li>
		<li> <a href="index.php" class="menu">Sobre el instituto</a> </li>
	</ul>
</nav>
</section>
